import React from 'react';

const App1 = () => {
    return (
        <div>
            <h1>Bienvenido a App1</h1>
            {/* Aquí puedes agregar más contenido */}
        </div>
    );
};

export default App1;